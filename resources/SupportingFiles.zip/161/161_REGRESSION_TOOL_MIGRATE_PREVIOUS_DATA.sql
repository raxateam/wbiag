CREATE OR REPLACE PACKAGE WORKBRAIN.REGRESSION_TOOL_SCRIPTS AUTHID CURRENT_USER AS
    PROCEDURE REGRESSION_TOOL_MIGRATE;
END REGRESSION_TOOL_SCRIPTS;
/

CREATE OR REPLACE PACKAGE BODY WORKBRAIN.REGRESSION_TOOL_SCRIPTS AS

PROCEDURE MIGRATE_TEST_SUITE
IS
    cursor oldData is 
        select 
        TEST_SUITE_ID,
        TEST_SUITE_NAME, 
        TEST_SUITE_DESC, 
        TEST_SUITE_TYPE, 
        TEST_SUITE_LAST_EXECUTED_DATE, 
        TEST_SUITE_CREATED_DATE, 
        TEST_SUITE_LAST_UPDATED_DATE, 
        TEST_SUITE_CREATOR_WBU_NAME, 
        CLIENT_ID 
        from WBIAG_TEST_SUITE;
        
    dataRecord WBIAG_TEST_SUITE%ROWTYPE;
    
    last_id number default 0;

BEGIN
    -- copy the data
    open oldData;
    
    for i in 0..99999 LOOP
    
        FETCH oldData into dataRecord;
        
        EXIT WHEN oldData%NOTFOUND;
        
        INSERT INTO WORKBRAIN.WBIAG_TST_SUITE
        (
            SUITE_ID, 
            SUITE_NAME,  
            SUITE_DESC, 
            SUITE_TYPE, 
            SUITE_EXECUTE_DATE, 
            SUITE_CREATED_DATE, 
            SUITE_UPDATED_DATE, 
            SUITE_CREATOR_NAME, 
            CLIENT_ID
        )
        VALUES
        (
            dataRecord.TEST_SUITE_ID,
            dataRecord.TEST_SUITE_NAME, 
            dataRecord.TEST_SUITE_DESC, 
            dataRecord.TEST_SUITE_TYPE, 
            dataRecord.TEST_SUITE_LAST_EXECUTED_DATE, 
            dataRecord.TEST_SUITE_CREATED_DATE, 
            dataRecord.TEST_SUITE_LAST_UPDATED_DATE, 
            dataRecord.TEST_SUITE_CREATOR_WBU_NAME, 
            dataRecord.CLIENT_ID
        );
    
    END LOOP;
    
    CLOSE oldData;
    
    
   
    -- update the sequence
    select nvl(max(SUITE_ID), 10000) into last_id from WORKBRAIN.WBIAG_TST_SUITE;
    last_id := last_id + 1;
    
    begin
        EXECUTE IMMEDIATE 'DROP SEQUENCE WORKBRAIN.SEQ_SUITE_ID';
    exception
        when others then null;
    end;

    EXECUTE IMMEDIATE 'CREATE SEQUENCE WORKBRAIN.SEQ_SUITE_ID START WITH ' || last_id || ' INCREMENT BY 1';     
    
END MIGRATE_TEST_SUITE;



PROCEDURE MIGRATE_TEST_CASE
IS
    cursor oldData is 
        select 
        RULES_CASE_ID, 
        TEST_SUITE_ID, 
        EMP_ID, 
        RULES_CASE_NAME, 
        RULES_CASE_DESC, 
        RULES_CASE_START_DATE, 
        RULES_CASE_END_DATE, 
        RULES_CASE_OUTPUT_ATTRIB, 
        RULES_CASE_EXPECTED_RESULTS, 
        RULES_CASE_CREATED_DATE, 
        RULES_CASE_LAST_UPDATED_DATE, 
        CLIENT_ID
        from WBIAG_PAY_RULES_TEST_CASE; 

    dataRecord WBIAG_PAY_RULES_TEST_CASE%ROWTYPE;
    
    last_id number default 0;
BEGIN
    -- copy the data
    open oldData;
    
    for i in 0..99999 LOOP
    
        FETCH oldData into dataRecord;
        
        EXIT WHEN oldData%NOTFOUND;

        INSERT INTO WORKBRAIN.WBIAG_RULES_CASE
        (
            CASE_ID, 
            SUITE_ID, 
            EMP_ID, 
            CASE_NAME, 
            CASE_DESC, 
            CASE_START_DATE, 
            CASE_END_DATE, 
            CASE_OUTPUT_ATTRIB, 
            CASE_EXPECT_RESULT, 
            CASE_CREATED_DATE, 
            CASE_UPDATED_DATE, 
            CLIENT_ID
        )
        VALUES
        (
            dataRecord.RULES_CASE_ID, 
            dataRecord.TEST_SUITE_ID, 
            dataRecord.EMP_ID, 
            dataRecord.RULES_CASE_NAME, 
            dataRecord.RULES_CASE_DESC, 
            dataRecord.RULES_CASE_START_DATE, 
            dataRecord.RULES_CASE_END_DATE, 
            dataRecord.RULES_CASE_OUTPUT_ATTRIB, 
            dataRecord.RULES_CASE_EXPECTED_RESULTS, 
            dataRecord.RULES_CASE_CREATED_DATE, 
            dataRecord.RULES_CASE_LAST_UPDATED_DATE, 
            dataRecord.CLIENT_ID
        );
    
    END LOOP;
    
    CLOSE oldData;
    
    -- update the sequence
    select nvl(max(CASE_ID), 10000) into last_id from WORKBRAIN.WBIAG_RULES_CASE;
    last_id := last_id + 1;
    
    begin
        EXECUTE IMMEDIATE 'DROP SEQUENCE WORKBRAIN.SEQ_CASE_ID';
    exception
        when others then null;
    end;

    EXECUTE IMMEDIATE 'CREATE SEQUENCE WORKBRAIN.SEQ_CASE_ID START WITH ' || last_id || ' INCREMENT BY 1';
    
END MIGRATE_TEST_CASE;



PROCEDURE MIGRATE_TEST_REPORT
IS
    cursor oldData is
        select
        TEST_REPORT_ID, 
        TEST_SUITE_ID, 
        TEST_REPORT_EXECUTED_DATE, 
        TEST_REPORT_OUTPUT, 
        CLIENT_ID 
        from WBIAG_TEST_SUITE_REPORT;
        
    dataRecord WBIAG_TEST_SUITE_REPORT%ROWTYPE;
        
    last_id number default 0;
BEGIN
    -- copy the data
    open oldData;
    
    for i in 0..99999 LOOP
    
        FETCH oldData into dataRecord;
        
        EXIT WHEN oldData%NOTFOUND;

        INSERT INTO WORKBRAIN.WBIAG_TST_REPORT
        (
            REPORT_ID, 
            SUITE_ID, 
            REPORT_DATE, 
            REPORT_OUTPUT, 
            CLIENT_ID
        )
        VALUES
        (
            dataRecord.TEST_REPORT_ID, 
            dataRecord.TEST_SUITE_ID, 
            dataRecord.TEST_REPORT_EXECUTED_DATE, 
            dataRecord.TEST_REPORT_OUTPUT, 
            dataRecord.CLIENT_ID 
        );
    
    END LOOP;
    
    CLOSE oldData;
    
    -- update the sequence
    select nvl(max(REPORT_ID), 10000) into last_id from WORKBRAIN.WBIAG_TST_REPORT;
    last_id := last_id + 1;
    
    begin
        EXECUTE IMMEDIATE 'DROP SEQUENCE WORKBRAIN.SEQ_TST_REPORT_ID';
    exception
        when others then null;
    end;

    EXECUTE IMMEDIATE 'CREATE SEQUENCE WORKBRAIN.SEQ_TST_REPORT_ID START WITH ' || last_id || 'INCREMENT BY 1';
    
END MIGRATE_TEST_REPORT;


PROCEDURE REGRESSION_TOOL_MIGRATE
IS
BEGIN

    MIGRATE_TEST_SUITE;
    
    MIGRATE_TEST_CASE;
    
    MIGRATE_TEST_REPORT;
    
    COMMIT;

END REGRESSION_TOOL_MIGRATE;


END REGRESSION_TOOL_SCRIPTS;