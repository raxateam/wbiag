--
-- Organization  :   Workbrain Inc.
-- Project       :   LIFESPAN
-- Author        :   Shailendra Nimbkar
--
-- DBMS          :   SQL Server 2000
--
--
-- required if PROCESS_CALC_EMP_DATE_TABLE is used
--
CREATE TABLE CALC_EMPLOYEE_DATE 
(
    CED_ID          INT          NOT NULL,
    EMP_ID          INTEGER      NOT NULL,
    CED_WORK_DATE   DATETIME     NOT NULL,
    CED_MESSAGE     VARCHAR(40)  NULL,
    CLIENT_ID       INTEGER      DEFAULT -1 NOT NULL,
    CONSTRAINT PK_CALCEMPDATE PRIMARY KEY (CED_ID)
)
ON WB_WORKBRAIN_DATA01


ALTER TABLE CALC_EMPLOYEE_DATE
  ADD CONSTRAINT FK_CED_CLID
    FOREIGN KEY (CLIENT_ID)
    REFERENCES WORKBRAIN_CLIENT (CLIENT_ID)
GO

DELETE FROM WB_SEQUENCE WHERE WBSEQ_NAME = 'SEQ_CED_ID'
go

INSERT INTO WB_SEQUENCE 
(WBSEQ_NAME,WBSEQ_VALUE,WBSEQ_INCREMENT) 
VALUES 
('SEQ_CED_ID',10021,1)
GO

--=============================
-- TRIGGER: TRG_JOBRATE_AU
-- Required if PROCESS_JOB_RATE_UPDATES is used
--=============================


CREATE TRIGGER WORKBRAIN.TRG_JOBRATE_AU
ON dbo.JOB_RATE
AFTER UPDATE
AS
BEGIN

DECLARE   @chrChangeType         CHAR (1)
DECLARE   @intChngHistRecordId   INT
DECLARE   @vcharChngHistRecName  VARCHAR(40)
DECLARE   @intClientID           INT
DECLARE   @eligible		VARCHAR(1) 
DECLARE   @effDate		DATETIME
DECLARE   @CHANGEID		INT
DECLARE  @JOBRATE_RATE_OLD     DECIMAL(10,5) 
DECLARE @JOBRATE_RATE_NEW       DECIMAL(10,5)
DECLARE @JOBRATE_EFFECTIVE_DATE_OLD  DATETIME
DECLARE	@JOBRATE_EFFECTIVE_DATE_NEW  DATETIME
DECLARE @CLIENT_ID_NEW 			 INT
DECLARE @JOB_RATE_ID_NEW 		 INT
	  
-- only create change history if rate or effective date is changed
IF (UPDATE(JOBRATE_RATE) OR UPDATE(JOBRATE_EFFECTIVE_DATE))
   BEGIN
       	-- Fetch and Update SEQUENCE Number
	SET @CHANGEID = dbo.UDF_SEQUENCE_GETVAL('SEQ_CHNGHIST_ID')
	UPDATE WB_SEQUENCE SET WBSEQ_VALUE= @CHANGEID + 1 WHERE  WBSEQ_NAME = 'SEQ_CHNGHIST_ID'
        --PRINT '@CHANGEID='+CAST(@CHANGEID AS varchar(20)) 
	SELECT  @JOBRATE_RATE_OLD  = JOBRATE_RATE FROM DELETED
	SELECT  @JOBRATE_RATE_NEW =  JOBRATE_RATE FROM INSERTED
	SELECT  @JOBRATE_EFFECTIVE_DATE_OLD  = JOBRATE_EFFECTIVE_DATE FROM DELETED
	SELECT  @JOBRATE_EFFECTIVE_DATE_NEW =  JOBRATE_EFFECTIVE_DATE FROM INSERTED
	SELECT  @CLIENT_ID_NEW =  CLIENT_ID FROM INSERTED
	SELECT  @JOB_RATE_ID_NEW =  JOB_ID FROM INSERTED
	--PRINT '@JOBRATE_RATE_NEW='+CAST(@JOBRATE_RATE_NEW AS varchar(20)) 
	--PRINT '@JOBRATE_RATE_OLD='+CAST(@JOBRATE_RATE_OLD AS varchar(20)) 
	
     
	IF ( @JOBRATE_RATE_OLD = @JOBRATE_RATE_NEW  AND  @JOBRATE_EFFECTIVE_DATE_OLD = @JOBRATE_EFFECTIVE_DATE_NEW)
        --BEGIN
	--PRINT '@JOBRATE_RATE_OLD <> @JOBRATE_RATE_NEW  OR  @JOBRATE_EFFECTIVE_DATE_OLD <> @JOBRATE_EFFECTIVE_DATE_NEW'    	
	RETURN
        --END  
	ELSE 
	  BEGIN
    		SET @chrChangeType = 'U'
    		SET @intChngHistRecordId  = @JOB_RATE_ID_NEW
    		SET @intClientID          = @CLIENT_ID_NEW
    
    		IF (@JOBRATE_RATE_OLD <> @JOBRATE_RATE_NEW)     
       			BEGIN
			--PRINT '@JOBRATE_RATE_OLD <> @JOBRATE_RATE_NEW'
         		SET @effDate = @JOBRATE_EFFECTIVE_DATE_NEW
         		SET @vcharChngHistRecName = CAST(@JOB_RATE_ID_NEW AS varchar(10)) + ',' + convert(varchar,@effDate,101) 
			--PRINT '@vcharChngHistRecName'+@vcharChngHistRecName       			
			END 
      -- if effective date changed find ealiest
    		IF (@JOBRATE_EFFECTIVE_DATE_NEW <> @JOBRATE_EFFECTIVE_DATE_OLD)
    			BEGIN
			--PRINT '@JOBRATE_EFFECTIVE_DATE_NEW <> @JOBRATE_EFFECTIVE_DATE_OLD'
          		SET @effDate = dbo.LEAST(@JOBRATE_EFFECTIVE_DATE_NEW , @JOBRATE_EFFECTIVE_DATE_OLD)
          	    	SET @vcharChngHistRecName =CAST(@JOB_RATE_ID_NEW AS varchar(10)) + ',' + convert(varchar,@effDate,101)
			--PRINT '@vcharChngHistRecName'+@vcharChngHistRecName
			END       			
		INSERT INTO CHANGE_HISTORY
   		(CHNGHIST_ID, CHNGHIST_CHANGE_DATE, CHNGHIST_TABLE_NAME, CHNGHIST_CHANGE_TYPE, CHNGHIST_RECORD_ID, CHNGHIST_REC_NAME, CLIENT_ID)
   		VALUES
   		(@CHANGEID, getDate(), 'JOB_RATE', @chrChangeType, @intChngHistRecordId, @vcharChngHistRecName, @intClientID)
     		
		END
     		
   	END
END
GO


--======================================================
-- TRIGGER: TRG_ENTEMPPOLICY_AIUD
-- Required if PROCESS_ENTEMPPOLICY_CHANGES is used
--======================================================

CREATE TRIGGER WORKBRAIN.TRG_ENTEMPPOLICY_AIUD
ON ENT_EMP_POLICY
AFTER INSERT,UPDATE,DELETE
AS

BEGIN

DECLARE   @chrChangeType         CHAR (1)
DECLARE   @intChngHistRecordId   INT
DECLARE   @vcharChngHistRecName  VARCHAR(40)
DECLARE   @intClientID           INT
DECLARE   @effStartDate         DATETIME
DECLARE   @effEndDate         DATETIME
DECLARE   @eligible         varchar(1) 
DECLARE  @CHANGEID          INT
DECLARE  @count_inserted    INT
DECLARE @count_deleted     INT
DECLARE @newEntemppolStartDate DATETIME
DECLARE @newEntemppolEndDate   DATETIME
DECLARE @oldEntemppolEndDate   DATETIME

  SELECT  @intChngHistRecordId  = EMP_ID FROM INSERTED
  SELECT  @intClientID          = CLIENT_ID FROM INSERTED
  SELECT @count_inserted = COUNT(*) FROM INSERTED  
  SELECT @count_deleted = COUNT(*) FROM DELETED
    -- Fetch and Update SEQUENCE Number
   SET @CHANGEID = dbo.UDF_SEQUENCE_GETVAL('SEQ_CHNGHIST_ID')
   UPDATE WB_SEQUENCE SET WBSEQ_VALUE= @CHANGEID + 1 WHERE  WBSEQ_NAME = 'SEQ_CHNGHIST_ID'
	--PRINT '@CHANGEID='+CAST(@CHANGEID AS varchar(10))
        --PRINT '@count_inserted ='+CAST(@count_inserted AS varchar(10))
	--PRINT '@count_deleted ='+CAST(@count_deleted AS varchar(10))
	
	-- inserting
    IF (@count_inserted=1 AND @count_deleted=0)  
       BEGIN
	--PRINT 'INSERTING @count_inserted >0 AND @count_deleted=0)'
        SELECT @chrChangeType = 'I'
        SELECT @effStartDate = ENTEMPPOL_START_DATE FROM INSERTED
        SELECT @effEndDate = ENTEMPPOL_END_DATE FROM INSERTED
        SELECT @vcharChngHistRecName = CONVERT( VARCHAR,@effStartDate,101) + ',' + CONVERT(VARCHAR,@effEndDate ,101)
       END
    ELSE
    --- updating 
	IF (@count_inserted=1 @count_inserted=1) 
	BEGIN        
	--PRINT 'UPDATEING (@count_inserted > 0 )'	
	SELECT @chrChangeType = 'U'
       -- if effective date changed find ealiest/latest
        SELECT @newEntemppolStartDate= ENTEMPPOL_START_DATE from INSERTED
        SELECT @newEntemppolEndDate= ENTEMPPOL_END_DATE from INSERTED
        SELECT @oldEntemppolEndDate= ENTEMPPOL_END_DATE from DELETED

	SET @effStartDate = dbo.LEAST(@newEntemppolStartDate , @newEntemppolEndDate)
        SET @effEndDate = dbo.GREATEST(@newEntemppolEndDate , @oldEntemppolEndDate)
        SET @vcharChngHistRecName = CONVERT( VARCHAR,@effStartDate , 101) + ',' + CONVERT( VARCHAR,@effEndDate ,101)
	END    
    ELSE 
	IF (@count_inserted = 0 AND @count_deleted=1)  
	BEGIN
	--PRINT 'DELETING @count_inserted = 0 AND @count_deleted > 0'	
	SELECT @intChngHistRecordId  = EMP_ID FROM DELETED
    	SELECT @intClientID          = CLIENT_ID FROM DELETED
        SELECT @chrChangeType = 'D'
        SELECT @effStartDate = ENTEMPPOL_START_DATE FROM DELETED
        SELECT @effEndDate = ENTEMPPOL_END_DATE FROM DELETED
        SELECT @vcharChngHistRecName = CONVERT( VARCHAR, @effStartDate , 101) + ',' + CONVERT(VARCHAR, @effEndDate , 101)
        END
    INSERT INTO CHANGE_HISTORY
        (CHNGHIST_ID, CHNGHIST_CHANGE_DATE, CHNGHIST_TABLE_NAME, CHNGHIST_CHANGE_TYPE, CHNGHIST_RECORD_ID, CHNGHIST_REC_NAME, CLIENT_ID)
    VALUES
       (@CHANGEID, getDate(), 'ENT_EMP_POLICY', @chrChangeType, @intChngHistRecordId, @vcharChngHistRecName, @intClientID);
END
GO

-- 
-- required if PROCESS_CLOCKS_PROCESSED is used
--
CREATE INDEX IDX_CLKTRANPROC_DATE
    ON CLOCK_TRAN_PROCESSED(CLKTRANPRO_PROC_DT)
	ON WB_WORKBRAIN_INDX01
