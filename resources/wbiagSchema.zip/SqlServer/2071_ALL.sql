DROP TABLE WBIAG_WBUSER_PWDS

DELETE FROM WB_SEQUENCE WHERE WBSEQ_NAME = 'SEQ_WUPW_ID'

CREATE TABLE WBIAG_WBUSER_PWDS
(
    WUPW_ID          BIGINT        NOT NULL,
    WBU_ID              BIGINT  NOT NULL,
    WUPW_PASSWORD        VARCHAR(4000)     NOT NULL,    
    WUPW_PWD_CHANGED_DATE       DATETIME  NOT    NULL,
    CLIENT_ID   INT        DEFAULT -1 NOT NULL,
CONSTRAINT PK_WBIAG_WBUSER_PWDS PRIMARY KEY (WUPW_ID),
CONSTRAINT FK_WUPW_WBUID
    FOREIGN KEY (WBU_ID)
    REFERENCES WORKBRAIN_USER (WBU_ID)
     ON DELETE CASCADE,
CONSTRAINT FK_WUPW_CLIENT_ID
    FOREIGN KEY (CLIENT_ID)
    REFERENCES WORKBRAIN_CLIENT (CLIENT_ID)
)
ON WB_WORKBRAIN_DATA01;

INSERT INTO WB_SEQUENCE
(WBSEQ_NAME,WBSEQ_VALUE,WBSEQ_INCREMENT) 
VALUES 
('SEQ_WUPW_ID',10000,1)

CREATE INDEX  IDX_WUPW_WBUID ON WBIAG_WBUSER_PWDS
(WBU_ID,CLIENT_ID) 
  ON WB_WORKBRAIN_DATA01
GO

CREATE TRIGGER TRG_WBUSER_AU
ON WORKBRAIN_USER
FOR UPDATE
AS
DECLARE @oldPassword VARCHAR(100)
DECLARE @newPassword VARCHAR(100)
DECLARE @seq_val BIGINT
DECLARE @seq_inc INT
 
SELECT @oldPassword = (SELECT SUBSTRING(wbu_password, 1,7) FROM Deleted)
SELECT @newPassword = (SELECT SUBSTRING(wbu_password, 1,7) FROM Inserted)

IF UPDATE(wbu_password) AND NOT UPDATE(wbu_id) AND @oldPassword = '{SHA-1}' AND @newPassword = '{SHA-1}'
BEGIN
SELECT @seq_val = wbseq_value, @seq_inc = wbseq_increment FROM wb_sequence WHERE wbseq_name = 'SEQ_WUPW_ID'

INSERT INTO wbiag_wbuser_pwds (wupw_id , wbu_id, wupw_password, wupw_pwd_changed_date, client_id)
        SELECT @seq_val, wbu_id, wbu_password, wbu_pwd_changed_date, client_id FROM Deleted
UPDATE wb_sequence 
SET wbseq_value = @seq_val + @seq_inc
WHERE wbseq_name = 'SEQ_WUPW_ID'

END