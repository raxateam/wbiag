create table wbiag_rule_trace
(
 wrt_id number not null,
 wrks_id number not null,
 wrt_trace clob null,
CLIENT_ID                   NUMBER DEFAULT -1 NOT NULL,
 CONSTRAINT FK_wrt_wrksid
    FOREIGN KEY (wrks_ID)
    REFERENCES WORKBRAIN.work_summary (wrks_ID)
     ON DELETE CASCADE,
CONSTRAINT FK_wrt_clientID
    FOREIGN KEY (CLIENT_ID)
    REFERENCES WORKBRAIN.WORKBRAIN_CLIENT (CLIENT_ID)
)
TABLESPACE WB_WORKBRAIN_DATA01;

ALTER TABLE WORKBRAIN.wbiag_rule_trace
    ADD CONSTRAINT PK_wbiag_rule_trace
PRIMARY KEY (wrt_ID)
    USING INDEX TABLESPACE WB_WORKBRAIN_INDX01;

ALTER TABLE WORKBRAIN.wbiag_rule_trace
  ADD CONSTRAINT UK_wrt_wrks_id
  UNIQUE(wrks_id, client_id)
      USING INDEX TABLESPACE WB_WORKBRAIN_INDX01;

CREATE SEQUENCE WORKBRAIN.SEQ_wrt_ID
    START WITH 1
    INCREMENT BY 1;