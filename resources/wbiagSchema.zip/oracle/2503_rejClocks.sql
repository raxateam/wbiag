SELECT emp_id, clktranrej_time, clktrantype_name, emp_id, rdr_name, clktranrej_error_mess, clktranrej_data

FROM clock_tran_rejected, reader,clock_tran_type

WHERE reader.rdr_id = clock_tran_rejected.rdr_id

AND clock_tran_type.clktrantype_id = clock_tran_rejected.clktrantype_id

AND clktranrej_time > sysdate � 1/24
