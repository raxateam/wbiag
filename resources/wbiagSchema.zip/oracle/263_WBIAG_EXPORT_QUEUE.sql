
CREATE TABLE WBIAG_EXPORT_QUEUE (
    WIEQ_ID                 INTEGER             NOT NULL,
    WIEQ_LOCK               INTEGER             ,
    WIEQ_STATUS             VARCHAR2(40)        NOT NULL,
    WIEQ_SUBMITTED_BY       VARCHAR2(40)        ,
    WIEQ_SUBMIT_DATE        DATE                NOT NULL,
    WIEQ_START_TIME         DATE                ,
    WIEQ_END_TIME           DATE                ,
    WIEQ_ERROR                VARCHAR2(4000)      ,
    WIEQ_PAYGRP_ID          INTEGER             ,
    WIEQ_EMP_IDS            VARCHAR2(4000)      ,
    WIEQ_PAYSYS_ID          INTEGER             ,
    WIEQ_START_DATE         DATE                ,
    WIEQ_END_DATE           DATE                ,
    WIEQ_USE_PAY_PERIOD     VARCHAR2(5)         ,
    WIEQ_ALL_READY_WHERE    VARCHAR2(4000)      ,
    WIEQ_ALL_READY_PAYGRPS  VARCHAR2(5)         ,
    WIEQ_CYCLE              VARCHAR2(40)        NOT NULL,
    WIEQ_ADJUST_DATES       VARCHAR2(5)         NOT NULL,
    WIEQ_WRITE_TO_FILE      VARCHAR2(5)         NOT NULL,
    WIEQ_MERGE_FILES        VARCHAR2(5)         NOT NULL,
    WIEQ_WRITE_TO_TABLE     VARCHAR2(5)         NOT NULL,
    WIEQ_TERM_ADD_DAYS      NUMERIC(10,1)          ,
    WIEQ_LOOK_BACK_DAYS     NUMERIC(10,1)          ,
    WIEQ_CHK_UNAUTH         VARCHAR2(5)         ,
    WIEQ_UDF1               VARCHAR2(40)        ,   
    WIEQ_UDF2               VARCHAR2(40)        ,   
    WIEQ_UDF3               VARCHAR2(40)        ,   
    WIEQ_UDF4               VARCHAR2(40)        ,   
    WIEQ_UDF5               VARCHAR2(40)        ,   
    WIEQ_FLAG1               VARCHAR2(5)        ,   
    WIEQ_FLAG2               VARCHAR2(5)        ,   
    WIEQ_FLAG3               VARCHAR2(5)        ,   
    WIEQ_FLAG4               VARCHAR2(5)        ,   
    WIEQ_FLAG5               VARCHAR2(5)        ,   
    WIEQ_EXTRA               VARCHAR2(4000)     ,
    CLIENT_ID                INTEGER            NOT NULL,
    CONSTRAINT PK_WBIAG_EXPORT_QUEUE PRIMARY KEY(WIEQ_ID)
        USING INDEX TABLESPACE WB_WORKBRAIN_INDX01
)   
/
CREATE SEQUENCE SEQ_WIEQ_ID START WITH 1
/
ALTER TABLE WBIAG_EXPORT_QUEUE ADD CONSTRAINT FK_WIEQ_CLID
    FOREIGN KEY(CLIENT_ID)
    REFERENCES WORKBRAIN_CLIENT(CLIENT_ID)
/
CREATE INDEX IDX_WIEQ_EXPSTATUS
ON WBIAG_EXPORT_QUEUE(WIEQ_STATUS, WIEQ_ID)
    TABLESPACE WB_WORKBRAIN_INDX01
/
CREATE INDEX IDX_WIEQ_EXPLOCK
ON WBIAG_EXPORT_QUEUE(WIEQ_LOCK, WIEQ_ID)
    TABLESPACE WB_WORKBRAIN_INDX01
/
ALTER TABLE WBIAG_EXPORT_QUEUE ADD (
    WIEQ_UDF6               VARCHAR2(40)        ,   
    WIEQ_UDF7               VARCHAR2(40)        ,   
    WIEQ_UDF8               VARCHAR2(40)        ,   
    WIEQ_UDF9               VARCHAR2(40)        ,   
    WIEQ_UDF10               VARCHAR2(40)        ,   
    WIEQ_FLAG6               VARCHAR2(5)        ,   
    WIEQ_FLAG7               VARCHAR2(5)        ,   
    WIEQ_FLAG8               VARCHAR2(5)        ,   
    WIEQ_FLAG9               VARCHAR2(5)        ,   
    WIEQ_FLAG10               VARCHAR2(5)        )   
/