--
-- required if PROCESS_CALC_EMP_DATE_TABLE is used
--
CREATE TABLE WORKBRAIN.CALC_EMPLOYEE_DATE 
(
    CED_ID     NUMBER        NOT NULL,
    EMP_ID NUMBER        NOT NULL,
    CED_WORK_DATE DATE        NOT NULL,
    CED_MESSAGE  VARCHAR2(40)  NULL,
    CLIENT_ID   NUMBER        DEFAULT -1 NOT NULL
)
TABLESPACE WB_WORKBRAIN_DATA01
/
ALTER TABLE WORKBRAIN.CALC_EMPLOYEE_DATE
  ADD CONSTRAINT FK_CED_CLID
    FOREIGN KEY (CLIENT_ID)
    REFERENCES WORKBRAIN.WORKBRAIN_CLIENT (CLIENT_ID)
/
ALTER TABLE WORKBRAIN.CALC_EMPLOYEE_DATE 
    ADD CONSTRAINT PK_CALCEMPDATE
PRIMARY KEY (CED_ID)
USING INDEX TABLESPACE WB_WORKBRAIN_INDX01
/
CREATE SEQUENCE WORKBRAIN.SEQ_CED_ID 
    START WITH 10021
    INCREMENT BY 1
/
CREATE INDEX  IDX_CED_EMP_ID_DATE ON CALC_EMPLOYEE_DATE (EMP_ID, CED_WORK_DATE,CLIENT_ID) 
   TABLESPACE WB_WORK_INDX01; 
ANALYZE  TABLE  CALC_EMPLOYEE_DATE  ESTIMATE STATISTICS SAMPLE 10 PERCENT;
ANALYZE INDEX  IDX_CED_EMP_ID_DATE ESTIMATE STATISTICS SAMPLE 10 PERCENT;
--
-- required if PROCESS_JOB_RATE_UPDATES is used
--
CREATE OR REPLACE TRIGGER WORKBRAIN.TRG_JOBRATE_AU
AFTER UPDATE
ON JOB_RATE
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
DECLARE
   chrChangeType         char (1);
   intChngHistRecordId   integer;
   vcharChngHistRecName  varchar2(40);
   intClientID           integer;
   eligible         boolean;
   effDate         date;
BEGIN
    -- only create change history iff rate or effective date is changed
    eligible := :OLD.JOBRATE_RATE <> :NEW.JOBRATE_RATE OR :OLD.JOBRATE_EFFECTIVE_DATE<> :NEW.JOBRATE_EFFECTIVE_DATE;
    if (not eligible) then
        return;
    end if;
    chrChangeType := 'U';
    intChngHistRecordId  := :NEW.JOBRATE_ID;
    intClientID          := :NEW.CLIENT_ID;
    if (:OLD.JOBRATE_RATE <> :NEW.JOBRATE_RATE)     THEN
         effDate := :NEW.JOBRATE_EFFECTIVE_DATE;
          vcharChngHistRecName := :NEW.JOB_ID || ',' || to_char( effDate ,  'mm/dd/yyyy');
    end if;
   -- if effective date changed find ealiest
    if (:OLD.JOBRATE_EFFECTIVE_DATE <> :NEW.JOBRATE_EFFECTIVE_DATE)     THEN
          effDate := LEAST(:NEW.JOBRATE_EFFECTIVE_DATE , :OLD.JOBRATE_EFFECTIVE_DATE);
          vcharChngHistRecName := :NEW.JOB_ID || ',' || to_char(effDate , 'mm/dd/yyyy');
    end if;
   INSERT INTO CHANGE_HISTORY
   (CHNGHIST_ID, CHNGHIST_CHANGE_DATE, CHNGHIST_TABLE_NAME, CHNGHIST_CHANGE_TYPE, CHNGHIST_RECORD_ID, CHNGHIST_REC_NAME, CLIENT_ID)
   VALUES
   (SEQ_CHNGHIST_ID.NEXTVAL, SYSDATE, 'JOB_RATE', chrChangeType, intChngHistRecordId, vcharChngHistRecName, intClientID);
END;
/
--
-- required if PROCESS_ENTEMPPOLICY_CHANGES is used
--
CREATE OR REPLACE TRIGGER WORKBRAIN.TRG_ENTEMPPOLICY_AIUD
AFTER  INSERT OR UPDATE OR DELETE
ON ENT_EMP_POLICY
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW
DECLARE
   chrChangeType         char (1);
   intChngHistRecordId   integer;
   vcharChngHistRecName  varchar2(40);
   intClientID           integer;
   effStartDate         date;
   effEndDate         date;
   eligible         boolean := true;
BEGIN
    intChngHistRecordId  := :NEW.EMP_ID;
    intClientID          := :NEW.CLIENT_ID;
    if (inserting) then 
        chrChangeType := 'I';
        effStartDate := :NEW.ENTEMPPOL_START_DATE;
        effEndDate := :NEW.ENTEMPPOL_END_DATE;
        vcharChngHistRecName := to_char( effStartDate ,  'mm/dd/yyyy') || ',' || to_char( effEndDate ,  'mm/dd/yyyy');
    elsif (updating) then
        chrChangeType := 'U';
       -- if effective date changed find ealiest/latest
        effStartDate := LEAST(:NEW.ENTEMPPOL_START_DATE , :OLD.ENTEMPPOL_START_DATE);
        effEndDate := GREATEST(:NEW.ENTEMPPOL_END_DATE , :OLD.ENTEMPPOL_END_DATE);
        vcharChngHistRecName := to_char( effStartDate ,  'mm/dd/yyyy') || ',' || to_char( effEndDate ,  'mm/dd/yyyy');
    elsif (deleting)  then
    	intChngHistRecordId  := :OLD.EMP_ID;
    	intClientID          := :OLD.CLIENT_ID;
        chrChangeType := 'D';
        effStartDate := :OLD.ENTEMPPOL_START_DATE;
        effEndDate := :OLD.ENTEMPPOL_END_DATE;
        vcharChngHistRecName := to_char( effStartDate ,  'mm/dd/yyyy') || ',' || to_char( effEndDate ,  'mm/dd/yyyy');
    end if;
    INSERT INTO CHANGE_HISTORY
        (CHNGHIST_ID, CHNGHIST_CHANGE_DATE, CHNGHIST_TABLE_NAME, CHNGHIST_CHANGE_TYPE, CHNGHIST_RECORD_ID, CHNGHIST_REC_NAME, CLIENT_ID)
    VALUES
       (SEQ_CHNGHIST_ID.NEXTVAL, SYSDATE, 'ENT_EMP_POLICY', chrChangeType, intChngHistRecordId, vcharChngHistRecName, intClientID);
END;
/


--
-- 
-- required if PROCESS_CLOCKS_PROCESSED is used
--
-- NOTE: This index is included in 5.0 core.  Please only add if not existing.
--
--CREATE INDEX WORKBRAIN.IDX_CLKTRANPROC_DATE
--    ON WORKBRAIN.CLOCK_TRAN_PROCESSED(clktranpro_proc_dt)
--TABLESPACE WB_WORKBRAIN_INDX01;