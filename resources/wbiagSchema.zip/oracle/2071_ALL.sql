CREATE TABLE WORKBRAIN.WBIAG_WBUSER_PWDS
(
    WUPW_ID          NUMBER        NOT NULL,
    WBU_ID              NUMBER  NOT NULL,
    WUPW_PASSWORD        VARCHAR2(4000)     NOT NULL,    
    WUPW_PWD_CHANGED_DATE       DATE  NOT    NULL,
    CLIENT_ID   NUMBER        DEFAULT -1 NOT NULL,
CONSTRAINT FK_WUPW_WBUID
    FOREIGN KEY (WBU_ID)
    REFERENCES WORKBRAIN.WORKBRAIN_USER (WBU_ID)
     ON DELETE CASCADE,
CONSTRAINT FK_WUPW_CLIENT_ID
    FOREIGN KEY (CLIENT_ID)
    REFERENCES WORKBRAIN.WORKBRAIN_CLIENT (CLIENT_ID)
)
TABLESPACE WB_WORKBRAIN_DATA01;
/
ALTER TABLE WORKBRAIN.WBIAG_WBUSER_PWDS
    ADD CONSTRAINT PK_WBIAG_WBUSER_PWDS
PRIMARY KEY (WUPW_ID)
    USING INDEX TABLESPACE WB_WORKBRAIN_INDX01;
/
CREATE SEQUENCE WORKBRAIN.SEQ_WUPW_ID
    START WITH 1
    INCREMENT BY 1;
/
CREATE INDEX  IDX_WUPW_WBUID ON WBIAG_WBUSER_PWDS
(WBU_ID,CLIENT_ID) 
   TABLESPACE WB_WORK_INDX01;
/
CREATE OR REPLACE TRIGGER WORKBRAIN.TRG_WBUSER_AU
AFTER UPDATE
ON WORKBRAIN.WORKBRAIN_USER
REFERENCING OLD AS OLD NEW AS NEW
FOR EACH ROW 
declare   
   
begin
      -- only log if system is not trying to hash and a change occurred
      if (:new.wbu_password <> :old.wbu_password      
           and substring(:old.wbu_password, 1,7) = '{SHA-1}' and substring(:new.wbu_password, 1,7) = '{SHA-1}' 
           and :new.wbu_id = :old.wbu_id) then
        insert into wbiag_wbuser_pwds (wupw_id , wbu_id, wupw_password, wupw_pwd_changed_date, client_id)
        values (seq_wupw_id.nextval, :old.wbu_id, :old.wbu_password, :old.wbu_pwd_changed_date, :old.client_id);
     end if;
end;
/