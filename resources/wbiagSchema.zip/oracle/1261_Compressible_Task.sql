--================================================================
-- TT45421 - 20050217 - add table SO_CSD_DETAIL
--================================================================

--================================================================
-- TABLE: SO_CSD_DETAIL 
--================================================================

CREATE TABLE SO_CSD_DETAIL (
    CSDDET_ID                 INTEGER          NOT NULL ,
    CSD_ID                    INTEGER          NOT NULL ,
    CSDDET_COMPRESS_VL        NUMBER(7,2)      DEFAULT 100 NOT NULL ,
    CSDDET_FLAG1              VARCHAR2(1)               ,
    CSDDET_FLAG2              VARCHAR2(1)               ,
    CSDDET_FLAG3              VARCHAR2(1)               ,
    CSDDET_FLAG4              VARCHAR2(1)               ,
    CSDDET_FLAG5              VARCHAR2(1)               ,
    CSDDET_UDF1               VARCHAR2(400)             ,
    CSDDET_UDF2               VARCHAR2(400)             ,
    CSDDET_UDF3               VARCHAR2(400)             ,
    CSDDET_UDF4               VARCHAR2(400)             ,
    CSDDET_UDF5               VARCHAR2(400)             ,
    CONSTRAINT PK_SO_CSD_DETAIL PRIMARY KEY ( CSDDET_ID )
          USING INDEX TABLESPACE WB_SOS_INDX01
)
TABLESPACE WB_SOS_DATA01
/


--================================================================
-- FOREIGN KEYS
--================================================================

ALTER TABLE SO_CSD_DETAIL 
  ADD CONSTRAINT FK_CSDDET_CSDID FOREIGN KEY (CSD_ID)
      REFERENCES SO_CLIENT_STFDEF (CSD_ID)
/

--================================================================
-- INDICES
--================================================================

CREATE INDEX IDX_CSDDET_CSDID
ON SO_CSD_DETAIL ( CSD_ID )
       TABLESPACE WB_WORKBRAIN_INDX01
/

--================================================================
-- SEQUENCES
--================================================================

CREATE SEQUENCE SEQ_CSDDET_ID START WITH 10001
/

