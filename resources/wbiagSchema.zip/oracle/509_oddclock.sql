select employee.emp_id, emp_fullname, wrks_work_date, count_clocks 
from (select   wrks_work_date, emp_id, count(wrks_id) count_clocks  
           from view_parse_clocks 
           where wrks_work_date = trunc(sysdate)
           group by wrks_work_date, emp_id 
           having mod(count(wrks_id), 2) = 1) odd_days, employee 
where odd_days.emp_id = employee.emp_id