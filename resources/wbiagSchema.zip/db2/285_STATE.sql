DROP TABLE WBIAG_STATE_MINWGE ;
DROP TABLE WBIAG_STATE ;
DROP SEQUENCE SEQ_WISTM_ID;
DROP SEQUENCE SEQ_WIST_ID;

CREATE TABLE WBIAG_STATE 
(
    WIST_ID          INTEGER        NOT NULL,
    WIST_NAME   VARCHAR(40) NOT NULL,
    WIST_DESC        VARCHAR(200)     ,    
    WIST_FLAG1       VARCHAR(1)           ,
    WIST_FLAG2       VARCHAR(1)           ,
    WIST_FLAG3       VARCHAR(1)           ,
    WIST_FLAG4       VARCHAR(1)           ,
    WIST_FLAG5       VARCHAR(1)           ,
    WIST_UDF1        VARCHAR(100)     ,
    WIST_UDF2        VARCHAR(100)     ,
    WIST_UDF3        VARCHAR(100)     ,
    WIST_UDF4        VARCHAR(100)     ,
    WIST_UDF5        VARCHAR(100)     ,
    WIST_FLAG6       VARCHAR(1)           ,
    WIST_FLAG7       VARCHAR(1)           ,
    WIST_FLAG8       VARCHAR(1)           ,
    WIST_FLAG9       VARCHAR(1)           ,
    WIST_FLAG10       VARCHAR(1)           ,
    WIST_UDF6        VARCHAR(100)     ,
    WIST_UDF7        VARCHAR(100)     ,
    WIST_UDF8        VARCHAR(100)     ,
    WIST_UDF9        VARCHAR(100)     ,
    WIST_UDF10        VARCHAR(100)   ,
    CONSTRAINT PK_WBIAG_STATE PRIMARY KEY (WIST_ID),
    CONSTRAINT UK_WIST_NAME UNIQUE(WIST_NAME)
)
IN WB_TBS04K01_REG
INDEX IN WB_TBS04K01_IDX
;



CREATE SEQUENCE SEQ_WIST_ID
    START WITH 1
    INCREMENT BY 1
;
---


CREATE TABLE WBIAG_STATE_MINWGE 
(
    WISTM_ID          INTEGER        NOT NULL,
    WIST_ID            INTEGER        NOT NULL,
    WISTM_EFF_DATE    TIMESTAMP NOT NULL,
    WISTM_MIN_WAGE        DECIMAL(10,5)        NOT NULL,  
    WISTM_FLAG1       VARCHAR(1)           ,
    WISTM_FLAG2       VARCHAR(1)           ,
    WISTM_FLAG3       VARCHAR(1)           ,
    WISTM_FLAG4       VARCHAR(1)           ,
    WISTM_FLAG5       VARCHAR(1)           ,
    WISTM_UDF1        VARCHAR(100)     ,
    WISTM_UDF2        VARCHAR(100)     ,
    WISTM_UDF3        VARCHAR(100)     ,
    WISTM_UDF4        VARCHAR(100)     ,
    WISTM_UDF5        VARCHAR(100)     ,
    WISTM_FLAG6       VARCHAR(1)           ,
    WISTM_FLAG7       VARCHAR(1)           ,
    WISTM_FLAG8       VARCHAR(1)           ,
    WISTM_FLAG9       VARCHAR(1)           ,
    WISTM_FLAG10       VARCHAR(1)           ,
    WISTM_UDF6        VARCHAR(100)     ,
    WISTM_UDF7        VARCHAR(100)     ,
    WISTM_UDF8        VARCHAR(100)     ,
    WISTM_UDF9        VARCHAR(100)     ,
    WISTM_UDF10        VARCHAR(100)     ,
    CONSTRAINT FK_WISTM_WISTID
     FOREIGN KEY (WIST_ID)
     REFERENCES WBIAG_STATE (WIST_ID) ON DELETE CASCADE,
    CONSTRAINT PK_WISTM_MINWGE PRIMARY KEY (WISTM_ID)
)
IN WB_TBS04K01_REG
INDEX IN WB_TBS04K01_IDX
;

CREATE SEQUENCE SEQ_WISTM_ID
    START WITH 1
    INCREMENT BY 1
;

-- triggers


CREATE TRIGGER TRG_WIST_AI
AFTER INSERT 
ON WBIAG_STATE
REFERENCING  NEW AS N
FOR EACH ROW MODE DB2SQL

    UPDATE cache_version SET csver_value = csver_value + 1
      WHERE csver_name = 'WbiagStateCache';


CREATE TRIGGER TRG_WIST_AU
AFTER UPDATE  
ON WBIAG_STATE
REFERENCING NEW AS N
FOR EACH ROW MODE DB2SQL

    UPDATE cache_version SET csver_value = csver_value + 1
      WHERE csver_name = 'WbiagStateCache';


CREATE TRIGGER TRG_WIST_AD
AFTER DELETE  
ON WBIAG_STATE
REFERENCING  OLD AS O
FOR EACH ROW MODE DB2SQL

    UPDATE cache_version SET csver_value = csver_value + 1
      WHERE csver_name = 'WbiagStateCache';



CREATE TRIGGER TRG_WISTM_AI
AFTER INSERT 
ON WBIAG_STATE_MINWGE
REFERENCING NEW AS N
FOR EACH ROW MODE DB2SQL
 
    UPDATE cache_version SET csver_value = csver_value + 1       
      WHERE csver_name = 'WbiagStateCache';

CREATE TRIGGER TRG_WISTM_AU
AFTER UPDATE 
ON WBIAG_STATE_MINWGE
REFERENCING NEW AS N
FOR EACH ROW MODE DB2SQL
 
    UPDATE cache_version SET csver_value = csver_value + 1       
      WHERE csver_name = 'WbiagStateCache';

CREATE TRIGGER TRG_WISTM_AD
AFTER DELETE 
ON WBIAG_STATE_MINWGE
REFERENCING OLD AS O
FOR EACH ROW MODE DB2SQL
 
    UPDATE cache_version SET csver_value = csver_value + 1       
      WHERE csver_name = 'WbiagStateCache';

insert into reserved_table(rsvdtb_id, rsvdtb_name)  values (-1000000, 'WBIAG_STATE');
insert into reserved_table(rsvdtb_id, rsvdtb_name)  values (-1000001, 'WBIAG_STATE_MINWGE');
commit;